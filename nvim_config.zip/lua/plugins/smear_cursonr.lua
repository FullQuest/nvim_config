return {
  "sphamba/smear-cursor.nvim",

  -- quick smear
  opts = {                                -- Default  Range
    stiffness = 0.8,                      -- 0.6      [0, 1]
    trailing_stiffness = 0.6,             -- 0.45     [0, 1]
    stiffness_insert_mode = 0.7,          -- 0.5      [0, 1]
    trailing_stiffness_insert_mode = 0.7, -- 0.5      [0, 1]
    damping = 0.95,                       -- 0.85     [0, 1]
    damping_insert_mode = 0.95,           -- 0.9      [0, 1]
    distance_stop_animating = 0.5,        -- 0.1      > 0
  },

  -- smooth no smear
  -- opts = {
  --   stiffness = 0.5,
  --   trailing_stiffness = 0.5,
  --   matrix_pixel_threshold = 0.5,
  -- },

  }
